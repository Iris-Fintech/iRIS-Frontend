"use strict";
(self["webpackChunkhugiris_nft"] = self["webpackChunkhugiris_nft"] || []).push([["src_route_tsx"],{

/***/ "./src/route.tsx":
/*!***********************!*\
  !*** ./src/route.tsx ***!
  \***********************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");
/* harmony import */ var react_router_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-router-dom */ "./node_modules/react-router/esm/react-router.js");
/* harmony import */ var _views_Home__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./views/Home */ "./src/views/Home/index.tsx");



const Routes = () => {
    return ((0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_router_dom__WEBPACK_IMPORTED_MODULE_2__.Switch, { children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(react_router_dom__WEBPACK_IMPORTED_MODULE_2__.Route, { exact: true, path: "/home", children: (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)(_views_Home__WEBPACK_IMPORTED_MODULE_1__["default"], {}, void 0) }, void 0) }, void 0));
};
/* harmony default export */ __webpack_exports__["default"] = (Routes);


/***/ }),

/***/ "./src/views/Home/index.tsx":
/*!**********************************!*\
  !*** ./src/views/Home/index.tsx ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-runtime */ "./node_modules/react/jsx-runtime.js");

const Home = () => {
    return (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx)("div", { children: "Home" }, void 0);
};
/* harmony default export */ __webpack_exports__["default"] = (Home);


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3JjX3JvdXRlX3RzeC5lZTRhODc4MjAyNzExZjI3NzQxOC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUNpRDtBQUNqQjtBQUVoQyxNQUFNLE1BQU0sR0FBRyxHQUFHLEVBQUU7SUFDaEIsT0FBTyxDQUNILHVEQUFDLG9EQUFNLGNBQ0gsdURBQUMsbURBQUssSUFBQyxLQUFLLFFBQUMsSUFBSSxFQUFDLE9BQU8sWUFDckIsdURBQUMsbURBQUksYUFBRyxXQUNKLFdBQ0gsQ0FDWixDQUFDO0FBQ04sQ0FBQyxDQUFDO0FBRUYsK0RBQWUsTUFBTSxFQUFDOzs7Ozs7Ozs7Ozs7OztBQ1p0QixNQUFNLElBQUksR0FBRyxHQUFHLEVBQUU7SUFDZCxPQUFPLDJGQUFlLENBQUM7QUFDM0IsQ0FBQyxDQUFDO0FBQ0YsK0RBQWUsSUFBSSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vaHVnaXJpcy1uZnQvLi9zcmMvcm91dGUudHN4Iiwid2VicGFjazovL2h1Z2lyaXMtbmZ0Ly4vc3JjL3ZpZXdzL0hvbWUvaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyBTd2l0Y2gsIFJvdXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgSG9tZSBmcm9tICcuL3ZpZXdzL0hvbWUnO1xuXG5jb25zdCBSb3V0ZXMgPSAoKSA9PiB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPFN3aXRjaD5cbiAgICAgICAgICAgIDxSb3V0ZSBleGFjdCBwYXRoPVwiL2hvbWVcIj5cbiAgICAgICAgICAgICAgICA8SG9tZSAvPlxuICAgICAgICAgICAgPC9Sb3V0ZT5cbiAgICAgICAgPC9Td2l0Y2g+XG4gICAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFJvdXRlcztcbiIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbmNvbnN0IEhvbWUgPSAoKSA9PiB7XG4gICAgcmV0dXJuIDxkaXY+SG9tZTwvZGl2Pjtcbn07XG5leHBvcnQgZGVmYXVsdCBIb21lO1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9